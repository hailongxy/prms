# Security Policy

## Supported Versions

| Version  | Supported          |
| -------- | ------------------ |
| Latest   | :white_check_mark: |
| Older    | :x:                |

## Reporting a Vulnerability

Email support@diagrams.net. If you do not wish to submit by email, please 
ask for an alternative via email or Github issue.